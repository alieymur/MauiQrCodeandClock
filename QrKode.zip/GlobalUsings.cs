﻿global using Microsoft.Maui.Graphics;
global using QrKode.Drawables;
global using System.Timers;
