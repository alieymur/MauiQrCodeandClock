﻿using QRCoder;
using System.Timers;
using Shared.Cryptography;
using System.Security.Cryptography;
using System.Text;


namespace QrKode;

public partial class MainPage : ContentPage
{
    //private DateTime CTime { get; set; } = DateTime.Now;
    //public DateTime currentTime { 
    //    get{ return CTime; }
    //    set {
    //        CTime = value;
    //        OnPropertyChanged();
    //        OnPropertyChanged("TextSure");
    //    }
    //}
    //public string TextSure
    //{
    //    get { return $"{currentTime}"; }
    //}


    private ImageSource QrCodeImageIS { get; set; }
    public ImageSource QrCodeImageSource
    {
        get { return QrCodeImageIS; }
        set
        {
            QrCodeImageIS = value;
            OnPropertyChanged();
            OnPropertyChanged("MauiQrCodeImageSource");
        }
    }
    public ImageSource MauiQrCodeImageSource
    {
        get { return QrCodeImageSource; }
    }


    private double PNumber { get; set; } = 0.01;
    public double progressbar
    {
        get { return PNumber; }
        set
        {
            PNumber = value;
            OnPropertyChanged();
            OnPropertyChanged("MauiProgressBar");
        }
    }
    public double MauiProgressBar
    {
        get { return progressbar; }
    }
    public MainPage()
	{
		InitializeComponent();
        BindingContext = this;
        DeviceDisplay.Current.KeepScreenOn = true;


        //QrCodeImage.Source = QrGenarate(currentTime.ToString());

        var timer = new System.Timers.Timer(1000);
        timer.Elapsed += new ElapsedEventHandler(RedrawClock);
        timer.Start();

        var timer2 = new System.Timers.Timer(100);
        timer2.Elapsed += new ElapsedEventHandler(ProgressBarEvent);
        timer2.Start();
    }

    private ImageSource QrGenarate(string sender)
    {
        QRCodeGenerator qrGenerator = new QRCodeGenerator();
        QRCodeData qrCodeData = qrGenerator.CreateQrCode(sender, QRCodeGenerator.ECCLevel.L);
        PngByteQRCode qRCode = new PngByteQRCode(qrCodeData);
        byte[] qrCodeBytes = qRCode.GetGraphic(20);
        //QrCodeImage.Source = ImageSource.FromStream(() => new MemoryStream(qrCodeBytes));
        return ImageSource.FromStream(() => new MemoryStream(qrCodeBytes));
    }

    public void RedrawClock(object source, ElapsedEventArgs e)
    {
        var currentTime = DateTime.Now;
        if (currentTime.Second % 30 == 0 )
        {
            progressbar = 0;
            var msg =CryptographyHelper.EncryptwithKey(currentTime.ToString());
            QrCodeImageSource = QrGenarate(msg);
            //var msg2 =CryptographyHelper.DecryptwithKey(msg);
        }

        //progressbar += 0.033;
        //var clock = (ClockDrawable) this.ClockGraphicsView.Drawable;
        var graphicsView = this.ClockGraphicsView;

        graphicsView.Invalidate();

    }

    public void ProgressBarEvent(object source, ElapsedEventArgs e)
    {
        progressbar += 0.0033;
    }
}

