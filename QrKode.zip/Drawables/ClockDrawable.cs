﻿using Microsoft.Maui.Graphics;

namespace QrKode.Drawables;

public class ClockDrawable : IDrawable
{

    public void Draw(ICanvas canvas, RectF dirtyRect)
    {
        DateTime curTime = DateTime.Now;
        var clockCenterPoint = new PointF(125, 125);
        var circleRadius = 100;
        var circleRadius2 = 115;
        var circleRadius3 = 125;

        canvas.StrokeColor = Colors.Gray;
        canvas.StrokeSize = 1;
        canvas.DrawCircle(clockCenterPoint, circleRadius2);

        canvas.StrokeColor = Colors.Grey;
        canvas.StrokeSize = 9;
        canvas.DrawCircle(clockCenterPoint, 4);

        canvas.StrokeSize = 5;
        var hourPoint = GetHourHand(curTime, circleRadius, clockCenterPoint);
        canvas.DrawLine(clockCenterPoint, hourPoint);

        canvas.StrokeSize = 3;
        var minutePoint = GetMinuteHand(curTime, circleRadius, clockCenterPoint);
        canvas.DrawLine(clockCenterPoint, minutePoint);

        
        canvas.StrokeSize = 1;
        canvas.StrokeColor = Colors.DarkRed;
        var secondPoint = GetSecondHand(curTime, circleRadius, clockCenterPoint);
        canvas.DrawLine(clockCenterPoint, secondPoint);

        drawNumbers(canvas, circleRadius3, clockCenterPoint);
    }

    internal static PointF GetHourHand(DateTime curTime, int radius, PointF center)
    {

        int currentHour = curTime.Hour;

        if (currentHour > 12)
            currentHour -= 12; 

        var angleDegrees = (currentHour * 360) / 12;
        var angle = (Math.PI / 180.0) * angleDegrees;

        var hourShorter = radius * .8;
        PointF outerPoint = new((float)(hourShorter * Math.Sin(angle)) + center.X, (float)(-hourShorter * Math.Cos(angle)) + center.Y);

        return outerPoint; 
    }

    internal static PointF GetMinuteHand(DateTime curTime, int radius, PointF center)
    {

        int currentMin =  curTime.Minute;

        var angleDegrees = (currentMin * 360) / 60;
        var angle = (Math.PI / 180.0) * angleDegrees; 

        PointF outerPoint = new((float)(radius * Math.Sin(angle)) + center.X, (float)(-radius * Math.Cos(angle)) + center.Y); 

        return outerPoint; 
    }
    
    internal static PointF GetSecondHand(DateTime curTime, int radius, PointF center)
    {

        int currentSecond = curTime.Second;

        var angleDegrees = (currentSecond * 360) / 60;
        var angle = (Math.PI / 180.0) * angleDegrees; 

        PointF outerPoint = new((float)(radius * Math.Sin(angle) + center.X), (float)(-radius * Math.Cos(angle)) + center.Y); 

        return outerPoint; 
    }


    internal static void drawNumbers(ICanvas canvas, int radius, PointF center)
    {
        canvas.FontSize= 19;
        canvas.FontColor = Colors.Grey;
;       center.Y += 8;
        for (int num = 1; num < 13; num++)
        {
            var angleDegrees = (num * 360) / 12;
            var angle = (Math.PI / 180.0) * angleDegrees;
            var hourShorter = radius * .8;

            PointF outerPoint = new((float)(hourShorter * Math.Sin(angle)) + center.X, (float)(-hourShorter * Math.Cos(angle)) + center.Y);
            canvas.DrawString(num.ToString(), outerPoint.X, outerPoint.Y, HorizontalAlignment.Center);

            //canvas.DrawString(num.ToString(), (int)ang, 10+num, 100+num, 100+num, HorizontalAlignment.Center, VerticalAlignment.Center);
        }
    }
}
